import mongoose from 'mongoose';

const candidateSchema = new mongoose.Schema({
  firstName: {
    type: String,
    required: true
  },
  lastName: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true
  },
  phone: {
    type: String,
    required: true
  },
  jobId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Job',
    required: true
  },
  resume: {
    type: String // File path or URL
  },
  coverLetter: {
    type: String
  },
  experience: {
    type: Number, // Years of experience
    default: 0
  },
  skills: [{
    type: String
  }],
  status: {
    type: String,
    enum: ['applied', 'screening', 'interview', 'hired', 'rejected'],
    default: 'applied'
  },
  appliedDate: {
    type: Date,
    default: Date.now
  },
  notes: {
    type: String
  }
}, {
  timestamps: true
});

export default mongoose.model('Candidate', candidateSchema);
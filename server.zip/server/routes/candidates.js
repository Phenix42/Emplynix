import express from 'express';
import Candidate from '../models/Candidate.js';
import Job from '../models/Job.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// Get all candidates grouped by job
router.get('/by-job', authenticateToken, async (req, res) => {
  try {
    const candidates = await Candidate.find()
      .populate('jobId', 'title company')
      .sort({ appliedDate: -1 });

    // Group candidates by job
    const candidatesByJob = candidates.reduce((acc, candidate) => {
      const jobId = candidate.jobId._id.toString();
      if (!acc[jobId]) {
        acc[jobId] = {
          job: candidate.jobId,
          candidates: [],
          count: 0
        };
      }
      acc[jobId].candidates.push(candidate);
      acc[jobId].count++;
      return acc;
    }, {});

    res.json(Object.values(candidatesByJob));
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get candidates for specific job
router.get('/job/:jobId', authenticateToken, async (req, res) => {
  try {
    const candidates = await Candidate.find({ jobId: req.params.jobId })
      .populate('jobId', 'title company')
      .sort({ appliedDate: -1 });
    
    res.json(candidates);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get all candidates
router.get('/', authenticateToken, async (req, res) => {
  try {
    const candidates = await Candidate.find()
      .populate('jobId', 'title company')
      .sort({ appliedDate: -1 });
    res.json(candidates);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Create candidate application
router.post('/', async (req, res) => {
  try {
    const candidate = new Candidate(req.body);
    await candidate.save();
    
    const populatedCandidate = await Candidate.findById(candidate._id)
      .populate('jobId', 'title company');
    
    res.status(201).json(populatedCandidate);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Update candidate status
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const candidate = await Candidate.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    ).populate('jobId', 'title company');

    if (!candidate) {
      return res.status(404).json({ message: 'Candidate not found' });
    }

    res.json(candidate);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Delete candidate
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const candidate = await Candidate.findByIdAndDelete(req.params.id);
    if (!candidate) {
      return res.status(404).json({ message: 'Candidate not found' });
    }
    res.json({ message: 'Candidate deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

export default router;